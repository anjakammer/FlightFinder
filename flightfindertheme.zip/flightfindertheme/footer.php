<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAqXVnrgrwAEb5XqokfoNhGR9USsonp5iQ&callback=initMap"></script>
<?php wp_footer(); ?>
</body>
</html>

